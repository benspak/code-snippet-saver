# Code Snippet Saver

Help me create a chrome browser app that saves code snippets. Users supply a title and the code itself. The title of each will be clickable and allow the code snippets to be viewed, edited, copied, or deleted.
